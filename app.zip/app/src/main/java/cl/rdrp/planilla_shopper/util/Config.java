package cl.rdrp.planilla_shopper.util;

public class Config {
    public static final int VALOR_POR_PEDIDO = 15000;
    public static final double RENDIMIENTO_KM_POR_LITRO = 10.0;
    public static final int PRECIO_LITRO = 1200;
    public static final double COMISION_PORC = 0.145; // 14.5%
}
